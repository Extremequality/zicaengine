::::::::::::::::::::::::::::::::::::::::::::::::::
 		>> Quick App >>
::::::::::::::::::::::::::::::::::::::::::::::::::



by Akshay Gaonkar (PARADOX)

__________________________________________________
Quick App v.1.1 (new 7za)
Quick App v.1.0
__________________________________________________




__________________________________________________
Files and Folder : Quick-App-v1.zip
__________________________________________________
1.Quick App.cmd (main file)

2.data.apk (apk data)

3.7za.exe (thanks to 7z , for zip)

4.Sign.cmd (sign apk)
{signapk.jar , test.pk8 ,testkey.x509.pem}

5. assets (folder for ur game data)
__________________________________________________




__________________________________________________  
How to use :
__________________________________________________

1. Open "Quick App.cmd" , and it will guide you step by step.

2. Once u complete the step 3 , u will get ur Quick App signed.

__________________________________________________




__________________________________________________
NOTE :
__________________________________________________
1. copy mean , all ur game code exproted as HTML5 wesite
   like eg. : index.html (the main file to load ur app in Apk) , and other .js files and    images .....

   eg:-
   /assets [Folder]
    {
     index.html (this file is loaded in apk)
     c2runtime.js
     icons.png ....
     jquery-2.0.0.min.js
     /images
     .
     .
     }


2. if u r using Quick App again , that means ur old game code will be there in the assets folder , just delete it so it dont merge with ur new game !

__________________________________________________
__________________________________________________

Have Fun ....
and Make Things Simple !

____________________________________________________________________________________________________
